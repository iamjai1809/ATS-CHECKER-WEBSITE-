import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()


st.set_page_config(
    page_title="Applicant Dashboard"
)

APPLICATIONS_FILE = "data/applications.csv"

os.makedirs(
    "data",
    exist_ok=True
)

# =========================
# LOGIN CHECK
# =========================

if "email" not in st.session_state:

    st.error(
        "Please login first."
    )

    st.stop()

email = st.session_state["email"]

# =========================
# APPLICATION FILE
# =========================

if not os.path.exists(
    APPLICATIONS_FILE
):

    pd.DataFrame(
        columns=[
            "name",
            "email",
            "phone",
            "resume_name",
            "job_title",
            "company_name",
            "status",
            "shortlisted"
        ]
    ).to_csv(
        APPLICATIONS_FILE,
        index=False
    )

# =========================
# LOAD DATA
# =========================

applications_df = pd.read_csv(
    APPLICATIONS_FILE,
    dtype=str
).fillna("")

if "company_name" not in applications_df.columns:
    applications_df["company_name"] = ""

if "shortlisted" not in applications_df.columns:
    applications_df["shortlisted"] = "No"

user_df = applications_df[
    applications_df["email"] == email
].copy()

# =========================
# SESSION STATE
# =========================

if "edit_mode" not in st.session_state:

    st.session_state[
        "edit_mode"
    ] = False

# =========================
# HEADER
# =========================

col1, col2 = st.columns(
    [8, 1]
)

with col1:

    st.title(
        "My Applications"
    )

with col2:

    if st.button(
        "Edit"
    ):

        st.session_state[
            "edit_mode"
        ] = not st.session_state[
            "edit_mode"
        ]

        st.rerun()

# =========================
# NO APPLICATIONS
# =========================

if user_df.empty:

    st.info(
        "You have not applied for any jobs yet."
    )

# =========================
# READ ONLY MODE
# =========================

elif not st.session_state[
    "edit_mode"
]:

    display_df = user_df.copy()

    current_phase = []
    next_round_status = []

    for _, row in display_df.iterrows():

        tech = row.get(
            "technical_round",
            ""
        )

        manager = row.get(
            "manager_round",
            ""
        )

        hr = row.get(
            "hr_round",
            ""
        )

        if tech == "Fail":

            current_phase.append(
                "Technical Round"
            )

            next_round_status.append(
                "Not Proceeding"
            )

        elif tech == "Pass" and manager == "":

            current_phase.append(
                "Technical Round"
            )

            next_round_status.append(
                "Proceeding to Manager Round"
            )

        elif manager == "Fail":

            current_phase.append(
                "Manager Round"
            )

            next_round_status.append(
                "Not Proceeding"
            )

        elif (
            tech == "Pass"
            and manager == "Pass"
            and hr == ""
        ):

            current_phase.append(
                "Manager Round"
            )

            next_round_status.append(
                "Proceeding to HR Round"
            )

        elif hr == "Fail":

            current_phase.append(
                "HR Round"
            )

            next_round_status.append(
                "Not Proceeding"
            )

        elif hr == "Pass":

            current_phase.append(
                "HR Round"
            )

            next_round_status.append(
                "Selected"
            )

        else:

            current_phase.append(
                "Application Under Review"
            )

            next_round_status.append(
                "Pending"
            )

    display_df["Current Interview Phase"] = (
        current_phase
    )

    display_df["Next Round Status"] = (
        next_round_status
    )

    display_df = display_df[
        [
            "company_name",
            "job_title",
            "Current Interview Phase",
            "Next Round Status"
        ]
    ]

    display_df.columns = [
        "Company Name",
        "Role",
        "Current Interview Phase",
        "Next Round Status"
    ]

    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True
    )

# =========================
# EDIT MODE
# =========================

else:

    st.info(
        "Edit Mode Enabled"
    )

    st.markdown("---")

    h1, h2, h3, h4, h5 = st.columns(
        [3, 4, 3, 4, 2]
    )

    h1.markdown("**Company Name**")
    h2.markdown("**Role**")
    h3.markdown("**Current Interview Phase**")
    h4.markdown("**Next Round Status**")
    h5.markdown("**Action**")

    st.markdown("---")

    for idx in user_df.index:

        row = user_df.loc[idx]

        c1, c2, c3, c4, c5 = st.columns(
            [3, 4, 3, 4, 2]
        )

        with c1:

            st.markdown(
                f"""
                <div style="
                    padding-top:10px;
                    white-space:nowrap;
                ">
                    {row['company_name']}
                </div>
                """,
                unsafe_allow_html=True
            )

        with c2:

            st.markdown(
                f"""
                <div style="
                    padding-top:10px;
                    white-space:nowrap;
                ">
                    {row['job_title']}
                </div>
                """,
                unsafe_allow_html=True
            )

        tech = row.get(
            "technical_round",
            ""
        )

        manager = row.get(
            "manager_round",
            ""
        )

        hr = row.get(
            "hr_round",
            ""
        )

        phase = ""
        status_text = ""

        if tech == "Fail":

            phase = "Technical Round"
            status_text = "Not Proceeding"

        elif tech == "Pass" and manager == "":

            phase = "Technical Round"
            status_text = (
                "Proceeding to Manager Round"
            )

        elif manager == "Fail":

            phase = "Manager Round"
            status_text = "Not Proceeding"

        elif (
            tech == "Pass"
            and manager == "Pass"
            and hr == ""
        ):

            phase = "Manager Round"
            status_text = (
                "Proceeding to HR Round"
            )

        elif hr == "Fail":

            phase = "HR Round"
            status_text = "Not Proceeding"

        elif hr == "Pass":

            phase = "HR Round"
            status_text = "Selected"

        else:

            phase = (
                "Application Under Review"
            )

            status_text = "Pending"

        with c3:

            st.text_input(
                label="",
                value=phase,
                disabled=True,
                key=f"phase_{idx}",
                label_visibility="collapsed"
            )

        with c4:

            st.text_input(
                label="",
                value=status_text,
                disabled=True,
                key=f"next_{idx}",
                label_visibility="collapsed"
            )

        with c5:

            if st.button(
                "Delete",
                key=f"delete_{idx}",
                use_container_width=True
            ):

                applications_df = applications_df.drop(
                    idx
                )

                applications_df.to_csv(
                    APPLICATIONS_FILE,
                    index=False
                )

                st.success(
                    "Application deleted successfully."
                )

                st.rerun()

        st.markdown("---")

    # =========================
    # ACTION BUTTONS
    # =========================

    save_col, cancel_col = st.columns(
        [1, 1]
    )

    with save_col:

        if st.button(
            "Save Changes",
            use_container_width=True
        ):

            applications_df.to_csv(
                APPLICATIONS_FILE,
                index=False
            )

            st.session_state[
                "edit_mode"
            ] = False

            st.success(
                "Changes saved successfully."
            )

            st.rerun()

    with cancel_col:

        if st.button(
            "Cancel Editing",
            use_container_width=True
        ):

            st.session_state[
                "edit_mode"
            ] = False

            st.rerun()