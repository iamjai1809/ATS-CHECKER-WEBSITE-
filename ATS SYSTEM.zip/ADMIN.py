import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()


st.set_page_config(
    page_title="Admin Portal"
)

st.title("Admin Portal")

USERS_FILE = "data/users.csv"

os.makedirs("data", exist_ok=True)

if not os.path.exists(USERS_FILE):

    pd.DataFrame(columns=[
        "email",
        "password",
        "role"
    ]).to_csv(
        USERS_FILE,
        index=False
    )

st.markdown("---")

admin_email = st.text_input(
    "Admin Email"
)

admin_password = st.text_input(
    "Admin Password",
    type="password"
)

col1, col2 = st.columns(2)

with col1:

    if st.button("Login"):

        users_df = pd.read_csv(
            USERS_FILE
        )

        admin_user = users_df[
            (users_df["email"] == admin_email)
            &
            (users_df["password"] == admin_password)
            &
            (users_df["role"] == "Admin")
        ]

        if len(admin_user) > 0:

            st.session_state[
                "admin_logged_in"
            ] = True

            st.session_state[
                "admin_email"
            ] = admin_email

            st.success(
                "Admin Login Successful"
            )

            st.switch_page(
                "pages/ADMIN DASHBOARD.py"
            )

        else:

            st.error(
                "Invalid Admin Credentials"
            )

with col2:

    if st.button("SIGN UP"):

        st.switch_page(
            "pages/ADMIN SIGNUP.py"
        )

st.markdown("---")

st.info(
    "This portal is restricted to administrators only."
)
