import streamlit as st
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()



import pandas as pd
import os

st.set_page_config(
    page_title="ATS Portal"
)

st.title("ATS Portal")

st.write(
    "Welcome to the ATS Portal! For logging in, please do it below. "
    "If you don't have an account, click Sign Up."
)

# ==================================
# LOGIN SECTION
# ==================================

USERS_FILE = "data/users.csv"

email = st.text_input("Email")

password = st.text_input(
    "Password",
    type="password"
)

role = st.selectbox(
    "Login As",
    ["Applicant", "Recruiter"]
)

if st.button("Login"):

    if not email or not password:
        st.error("Please enter email and password")

    elif not os.path.exists(USERS_FILE):
        st.error("No accounts found. Please sign up first.")

    else:

        users_df = pd.read_csv(USERS_FILE)

        # Check if role column exists
        if "role" not in users_df.columns:

            st.error(
                "User not found. Please create a new account. Using the 'Sign Up' button below."
            )

        else:

            # Validate email, password and role
            user = users_df[
                (users_df["email"] == email) &
                (users_df["password"] == password) &
                (users_df["role"] == role)
            ]

            if len(user) == 0:

                st.error(
                    "Account not found. Please sign up first or select the correct role."
                )

            else:

                st.session_state["logged_in"] = True
                st.session_state["email"] = email
                st.session_state["role"] = role

                st.success("Login Successful")

                # Applicant Redirect
                if role == "Applicant":

                    st.switch_page(
                        "pages/APPLICANT SIDE JOB POSTINGS.py"
                    )

                # Recruiter Redirect
                elif role == "Recruiter":

                    st.switch_page(
                        "pages/RECRUITER SIDE JOB POSTINGS.py"
                    )

# ==================================
# SIGNUP SECTION
# ==================================

st.markdown("---")

st.write(
    "Don't have an account? Please click the button below."
)

if st.button("Sign Up"):

    st.switch_page(
        "pages/SIGN UP.py"
    )

