import streamlit as st
import pandas as pd
import os
import re

from PyPDF2 import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()



st.set_page_config(
    page_title="Job Application"
)

st.title("Job Application")

APPLICATIONS_FILE = "data/applications.csv"

os.makedirs(
    "data",
    exist_ok=True
)

# =========================
# SESSION STATE
# =========================

if "application_submitted" not in st.session_state:

    st.session_state[
        "application_submitted"
    ] = False

# =========================
# HELPER FUNCTIONS
# =========================

def extract_resume_text(uploaded_file):

    text = ""

    try:

        pdf_reader = PdfReader(
            uploaded_file
        )

        for page in pdf_reader.pages:

            page_text = page.extract_text()

            if page_text:
                text += page_text

    except Exception:

        text = ""

    return text


def calculate_match_score(
    resume_text,
    job_description
):

    if (
        not resume_text
        or not job_description
    ):
        return 0

    try:

        documents = [
            resume_text,
            job_description
        ]

        vectorizer = TfidfVectorizer(
            stop_words="english"
        )

        vectors = vectorizer.fit_transform(
            documents
        )

        similarity = cosine_similarity(
            vectors
        )

        score = round(
            similarity[0][1] * 100,
            2
        )

        return score

    except Exception:

        return 0

# =========================
# CREATE APPLICATION FILE
# =========================

if not os.path.exists(
    APPLICATIONS_FILE
):

    pd.DataFrame(columns=[
        "name",
        "email",
        "phone",
        "resume_name",
        "job_title",
        "company_name",
        "match_score",
        "status"
    ]).to_csv(
        APPLICATIONS_FILE,
        index=False
    )

# =========================
# JOB DETAILS
# =========================

job_title = st.session_state.get(
    "selected_job",
    "No Job Selected"
)

company_name = st.session_state.get(
    "selected_company",
    "Unknown Company"
)

job_description = st.session_state.get(
    "selected_description",
    ""
)

# =========================
# SHOW FORM
# =========================

if not st.session_state.get(
    "application_submitted",
    False
):

    st.write(
        f"Applying For: {job_title}"
    )

    st.write(
        f"Company: {company_name}"
    )

    st.markdown("---")

    name = st.text_input(
        "Full Name"
    )

    email = st.text_input(
        "Email",
        value=st.session_state.get(
            "email",
            ""
        ),
        disabled=True
    )

    phone = st.text_input(
        "Phone Number"
    )

    resume = st.file_uploader(
        "Upload Resume",
        type=["pdf"]
    )

    # =========================
    # ATS SCORE (HIDDEN)
    # =========================

    match_score = 0

    if resume is not None:

        resume_text = extract_resume_text(
            resume
        )

        match_score = calculate_match_score(
            resume_text,
            job_description
        )

    # =========================
    # SUBMIT
    # =========================

    if st.button(
        "Submit Application"
    ):

        if not all([
            name,
            phone,
            resume
        ]):

            st.error(
                "Please fill all fields and upload your resume."
            )

        else:

            EMAIL_PATTERN = (
                r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
            )

            if not re.match(
                EMAIL_PATTERN,
                st.session_state.get(
                    "email",
                    ""
                )
            ):

                st.error(
                    "Please enter a valid email address."
                )

            else:

                try:

                    applications_df = pd.read_csv(
                        APPLICATIONS_FILE,
                        dtype=str
                    ).fillna("")

                except Exception:

                    applications_df = pd.DataFrame(
                        columns=[
                            "name",
                            "email",
                            "phone",
                            "resume_name",
                            "job_title",
                            "company_name",
                            "match_score",
                            "status"
                        ]
                    )

                new_application = pd.DataFrame([
                    {
                        "name": name,
                        "email": st.session_state["email"],
                        "phone": phone,
                        "resume_name": resume.name,
                        "job_title": job_title,
                        "company_name": company_name,
                        "match_score": str(match_score),
                        "status": "Applied"
                    }
                ])

                applications_df = pd.concat(
                    [
                        applications_df,
                        new_application
                    ],
                    ignore_index=True
                )

                applications_df.to_csv(
                    APPLICATIONS_FILE,
                    index=False
                )

                st.session_state[
                    "application_submitted"
                ] = True

                st.rerun()
# =========================
# THANK YOU PAGE
# =========================

else:

    st.success(
        "Application Submitted Successfully ✅"
    )

    st.markdown("---")

    st.subheader(
        "Thank You For Applying"
    )

    st.write(
        "Thank you for taking the time to apply for this role. Our recruitment team will review your application and resume."
    )

    st.write(
        "If your qualifications and experience match our requirements, we will reach out to you for the next steps in the hiring process."
    )

    st.markdown("---")

    if st.button(
        "Go To Dashboard"
    ):

        st.session_state[
            "application_submitted"
        ] = False

        st.switch_page(
            "pages/APPLICANT DASHBOARD.py"
        )

