import streamlit as st
import pandas as pd
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()




st.set_page_config(
    page_title="Recruiter Profile"
)

st.title("Recruiter Profile")

if "email" not in st.session_state:
    st.error("Please login first.")
    st.stop()

email = st.session_state["email"]

# =========================
# LOAD USERS FILE SAFELY
# =========================

users_df = pd.read_csv(
    "data/users.csv",
    dtype=str
).fillna("")

required_columns = [
    "name",
    "email",
    "role",
    "phone",
    "skills"
]

for col in required_columns:
    if col not in users_df.columns:
        users_df[col] = ""

user_index = users_df[
    users_df["email"] == email
].index

if len(user_index) == 0:

    st.error("User not found.")

else:

    idx = user_index[0]

    # =========================
    # NAME
    # =========================

    col1, col2 = st.columns([4, 1])

    with col1:
        st.write(
            f"Name: {str(users_df.at[idx, 'name'])}"
        )

    with col2:
        if st.button(
            "Change",
            key="change_name"
        ):
            st.session_state["edit_name"] = True

    if st.session_state.get(
        "edit_name",
        False
    ):

        new_name = st.text_input(
            "New Name",
            value=str(
                users_df.at[idx, "name"]
            )
        )

        if st.button("Save Name"):

            users_df.at[
                idx,
                "name"
            ] = str(new_name).strip()

            users_df.to_csv(
                "data/users.csv",
                index=False
            )

            st.session_state[
                "edit_name"
            ] = False

            st.success(
                "Name updated successfully."
            )

            st.rerun()

    # =========================
    # EMAIL
    # =========================

    col1, col2 = st.columns([4, 1])

    with col1:
        st.write(
            f"Email: {str(users_df.at[idx, 'email'])}"
        )

    with col2:
        if st.button(
            "Change",
            key="change_email"
        ):
            st.session_state["edit_email"] = True

    if st.session_state.get(
        "edit_email",
        False
    ):

        new_email = st.text_input(
            "New Email",
            value=str(
                users_df.at[idx, "email"]
            )
        )

        if st.button(
            "Save Email"
        ):

            existing_user = users_df[
                users_df["email"]
                == new_email
            ]

            if (
                len(existing_user) > 0
                and new_email
                != users_df.at[
                    idx,
                    "email"
                ]
            ):

                st.error(
                    "Email already registered."
                )

            else:

                users_df.at[
                    idx,
                    "email"
                ] = str(
                    new_email
                ).strip()

                users_df.to_csv(
                    "data/users.csv",
                    index=False
                )

                st.session_state[
                    "email"
                ] = new_email

                st.session_state[
                    "edit_email"
                ] = False

                st.success(
                    "Email updated successfully."
                )

                st.rerun()

    # =========================
    # ROLE
    # =========================

    st.write(
        f"Role: {str(users_df.at[idx, 'role'])}"
    )

    # =========================
    # PHONE
    # =========================

    col1, col2 = st.columns([4, 1])

    phone_value = str(
        users_df.at[idx, "phone"]
    )

    if phone_value.endswith(".0"):
        phone_value = phone_value[:-2]

    with col1:
        st.write(
            f"Phone Number: {phone_value}"
        )

    with col2:
        if st.button(
            "Change",
            key="change_phone"
        ):
            st.session_state[
                "edit_phone"
            ] = True

    if st.session_state.get(
        "edit_phone",
        False
    ):

        new_phone = st.text_input(
            "New Phone Number",
            value=phone_value
        )

        if st.button(
            "Save Phone"
        ):

            users_df.at[
                idx,
                "phone"
            ] = str(
                new_phone
            ).strip()

            users_df.to_csv(
                "data/users.csv",
                index=False
            )

            st.session_state[
                "edit_phone"
            ] = False

            st.success(
                "Phone number updated successfully."
            )

            st.rerun()

    # =========================
    # SKILLS
    # =========================

    col1, col2 = st.columns([4, 1])

    skills_value = str(
        users_df.at[idx, "skills"]
    )

    if skills_value.lower() == "nan":
        skills_value = ""

    with col1:
        st.write(
            f"Skills: {skills_value}"
        )

    with col2:
        if st.button(
            "Change",
            key="change_skills"
        ):
            st.session_state[
                "edit_skills"
            ] = True

    if st.session_state.get(
        "edit_skills",
        False
    ):

        new_skills = st.text_area(
            "New Skills",
            value=skills_value
        )

        if st.button(
            "Save Skills"
        ):

            users_df.at[
                idx,
                "skills"
            ] = str(
                new_skills
            ).strip()

            users_df.to_csv(
                "data/users.csv",
                index=False
            )

            st.session_state[
                "edit_skills"
            ] = False

            st.success(
                "Skills updated successfully."
            )

            st.rerun()

st.markdown("---")

if st.button(
    "Back To Recruiter Portal"
):
    st.switch_page(
        "pages/RECRUITER SIDE JOB POSTINGS.py"
    )

if st.button(
    "Go to Dashboard"
):
    st.switch_page(
        "pages/RECRUITER DASHBOARD.py"
    )

if st.button("Logout"):

    st.session_state[
        "logged_in"
    ] = False

    st.session_state[
        "role"
    ] = None

    st.switch_page(
        "HOME.py"
    )