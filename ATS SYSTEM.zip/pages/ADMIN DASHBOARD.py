import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()


st.set_page_config(
    page_title="Admin Dashboard"
)

st.title("Admin Dashboard")

# =========================
# LOGIN CHECK
# =========================

if not st.session_state.get(
    "admin_logged_in",
    False
):

    st.error(
        "Please login through Admin Portal."
    )

    st.stop()

# =========================
# FILES
# =========================

USERS_FILE = "data/users.csv"
JOBS_FILE = "data/jobs.csv"
APPLICATIONS_FILE = "data/applications.csv"
DASHBOARD_FILE = "data/dashboard.csv"

# =========================
# SAFE READ FUNCTION
# =========================

def load_csv(file_path):

    if not os.path.exists(file_path):

        return pd.DataFrame()

    try:

        return pd.read_csv(file_path)

    except:

        return pd.DataFrame()

# =========================
# LOAD DATA
# =========================

users_df = load_csv(
    USERS_FILE
)

jobs_df = load_csv(
    JOBS_FILE
)

applications_df = load_csv(
    APPLICATIONS_FILE
)

dashboard_df = load_csv(
    DASHBOARD_FILE
)

# =========================
# METRICS
# =========================

total_users = len(users_df)

total_applicants = len(
    users_df[
        users_df.get(
            "role",
            pd.Series()
        ) == "Applicant"
    ]
) if not users_df.empty else 0

total_recruiters = len(
    users_df[
        users_df.get(
            "role",
            pd.Series()
        ) == "Recruiter"
    ]
) if not users_df.empty else 0

total_jobs = len(
    jobs_df
)

total_applications = len(
    applications_df
)

st.markdown("---")

col1, col2, col3, col4, col5, col6 = st.columns(6)

with col1:
    st.metric(
        "Users",
        total_users
    )

with col2:
    st.metric(
        "Applicants",
        total_applicants
    )

with col3:
    st.metric(
        "Recruiters",
        total_recruiters
    )

with col4:
    st.metric(
        "Jobs",
        total_jobs
    )

with col5:
    st.metric(
        "Applications",
        total_applications
    )

with col6:
    st.metric(
        "Admins",
        len(
            users_df[
                users_df.get(
                    "role",
                    pd.Series()
                ) == "Admin"
            ]
        ) if not users_df.empty else 0
    )

# =========================
# TABS
# =========================

tab1, tab2, tab3, tab4 = st.tabs(
    [
        "Users",
        "Jobs",
        "Applications",
        "Dashboards"
    ]
)

# =========================
# USERS
# =========================

with tab1:

    st.subheader(
        "Manage Users"
    )

    edited_users = st.data_editor(
        users_df,
        use_container_width=True,
        hide_index=True
    )

    if st.button(
        "Save User Changes"
    ):

        edited_users.to_csv(
            USERS_FILE,
            index=False
        )

        st.success(
            "Users Updated Successfully"
        )

# =========================
# JOBS
# =========================

with tab2:

    st.subheader(
        "Manage Jobs"
    )

    edited_jobs = st.data_editor(
        jobs_df,
        use_container_width=True,
        hide_index=True
    )

    if st.button(
        "Save Job Changes"
    ):

        edited_jobs.to_csv(
            JOBS_FILE,
            index=False
        )

        st.success(
            "Jobs Updated Successfully"
        )

# =========================
# APPLICATIONS
# =========================

with tab3:

    st.subheader(
        "Manage Applications"
    )

    st.write(
        f"Total Applications: {len(applications_df)}"
    )

    if not applications_df.empty:

        if "status" in applications_df.columns:

            status_counts = applications_df[
                "status"
            ].value_counts()

            st.write(
                "Application Status Summary"
            )

            st.dataframe(
                status_counts.reset_index().rename(
                    columns={
                        "index": "Status",
                        "status": "Count"
                    }
                ),
                use_container_width=True
            )

    edited_applications = st.data_editor(
        applications_df,
        use_container_width=True,
        hide_index=True
    )

    if st.button(
        "Save Application Changes"
    ):

        edited_applications.to_csv(
            APPLICATIONS_FILE,
            index=False
        )

        st.success(
            "Applications Updated Successfully"
        )

# =========================
# DASHBOARDS
# =========================

with tab4:

    st.subheader(
        "Manage Dashboard Entries"
    )

    edited_dashboard = st.data_editor(
        dashboard_df,
        use_container_width=True,
        hide_index=True
    )

    if st.button(
        "Save Dashboard Changes"
    ):

        edited_dashboard.to_csv(
            DASHBOARD_FILE,
            index=False
        )

        st.success(
            "Dashboard Updated Successfully"
        )

# =========================
# PROFILE + LOGOUT
# =========================

st.markdown("---")

col1, col2, col3 = st.columns([8, 1, 1])

with col2:

    if st.button(
        "Profile"
    ):

        st.switch_page(
            "pages/ADMIN PROFILE.py"
        )

with col3:

    if st.button(
        "Logout"
    ):

        st.session_state.clear()

        st.switch_page(
            "ADMIN.py"
        )