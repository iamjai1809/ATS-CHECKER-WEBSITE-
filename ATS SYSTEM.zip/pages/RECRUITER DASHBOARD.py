import streamlit as st
import pandas as pd
import os

st.set_page_config(
    page_title="Recruiter Dashboard"
)

st.title("Recruiter Dashboard")

# =========================
# LOGIN CHECK
# =========================

if "logged_in" not in st.session_state:
    st.error("Please login first.")
    st.stop()

if "email" not in st.session_state:
    st.error("Please login first.")
    st.stop()

current_recruiter = st.session_state["email"]

# =========================
# FILE PATH
# =========================

JOBS_FILE = "data/jobs.csv"

os.makedirs("data", exist_ok=True)

if not os.path.exists(JOBS_FILE):

    pd.DataFrame(columns=[
        "job_title",
        "location",
        "experience",
        "description",
        "qualifications",
        "salary",
        "posted_by"
    ]).to_csv(
        JOBS_FILE,
        index=False
    )

# =========================
# LOAD JOBS
# =========================

jobs_df = pd.read_csv(JOBS_FILE)

if "posted_by" not in jobs_df.columns:
    jobs_df["posted_by"] = ""

my_jobs = jobs_df[
    jobs_df["posted_by"] == current_recruiter
]

# =========================
# TOP BUTTONS
# =========================

col1, col2 = st.columns([8, 1])

with col2:

    if st.button("Profile"):

        st.switch_page(
            "pages/RECRUITER PROFILE.py"
        )

# =========================
# DASHBOARD METRICS
# =========================

total_jobs = len(my_jobs)

col1, col2, col3 = st.columns(3)

with col1:
    st.metric(
        "Jobs Posted",
        total_jobs
    )

with col2:
    st.metric(
        "Active Jobs",
        total_jobs
    )

with col3:
    st.metric(
        "Total Locations",
        my_jobs["location"].nunique()
        if len(my_jobs) > 0 else 0
    )

# =========================
# MY JOBS TABLE
# =========================

st.markdown("---")

header_col1, header_col2 = st.columns([8, 1])

with header_col1:
    st.subheader("My Posted Jobs")

with header_col2:

    if st.button("➕ Add"):

        st.switch_page(
            "pages/RECRUITER SIDE JOB POSTINGS.py"
        )

if len(my_jobs) == 0:

    st.info(
        "You haven't posted any jobs yet."
    )

else:

    st.dataframe(
        my_jobs[
            [
                "job_title",
                "location",
                "experience",
                "salary"
            ]
        ],
        use_container_width=True,
        hide_index=True
    )

# =========================
# JOB DETAILS SECTION
# =========================

st.markdown("---")

st.subheader("Job Details")

if len(my_jobs) > 0:

    for _, job in my_jobs.iterrows():

        with st.expander(
            f"{job['job_title']} - {job['location']}"
        ):

            st.write(
                f"**Experience Required:** {job['experience']}"
            )

            st.write(
                f"**Salary Offered:** {job['salary']}"
            )

            st.write(
                f"**Description:** {job['description']}"
            )

            st.write(
                f"**Qualifications:** {job['qualifications']}"
            )

else:

    st.info(
        "Post jobs to see details here."
    )

# =========================
# FUTURE ATS SECTION
# =========================

st.markdown("---")

st.subheader("Applicants Received")

st.info(
    "Please press the button below to continue to the Applicant Tracking System (ATS) module."
)

if st.button("Go to ATS Module"):
    st.switch_page(
        "pages/APPLICANT TRACKING MODULE.py"
    )

# =========================
# BACK BUTTON
# =========================

st.markdown("---")

if st.button("Back To Recruiter Portal"):

    st.switch_page(
        "pages/RECRUITER SIDE JOB POSTINGS.py"
    )