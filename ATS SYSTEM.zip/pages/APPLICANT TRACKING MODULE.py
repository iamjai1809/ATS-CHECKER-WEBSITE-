import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()




st.set_page_config(
    page_title="Applicant Tracking Module"
)

st.title("Applicant Tracking Module")

# =========================
# LOGIN CHECK
# =========================

if "email" not in st.session_state:

    st.error(
        "Please login first."
    )

    st.stop()

# =========================
# FILE
# =========================

APPLICATIONS_FILE = "data/applications.csv"

os.makedirs(
    "data",
    exist_ok=True
)

# =========================
# CREATE FILE IF NEEDED
# =========================

if not os.path.exists(
    APPLICATIONS_FILE
):

    pd.DataFrame(columns=[
        "name",
        "email",
        "phone",
        "resume_name",
        "job_title",
        "status",
        "match_score"
    ]).to_csv(
        APPLICATIONS_FILE,
        index=False
    )

# =========================
# LOAD APPLICATIONS SAFELY
# =========================

try:

    applications_df = pd.read_csv(
        APPLICATIONS_FILE,
        dtype=str
    ).fillna("")

except (
    pd.errors.EmptyDataError,
    pd.errors.ParserError
):

    applications_df = pd.DataFrame(columns=[
        "name",
        "email",
        "phone",
        "resume_name",
        "job_title",
        "status",
        "match_score"
    ])

# =========================
# ENSURE REQUIRED COLUMNS
# =========================

required_columns = [

    "name",
    "email",
    "phone",
    "resume_name",
    "job_title",
    "status",
    "match_score"

]

for col in required_columns:

    if col not in applications_df.columns:

        if col == "status":

            applications_df[col] = "Applied"

        elif col == "match_score":

            applications_df[col] = "0"

        else:

            applications_df[col] = ""

applications_df = applications_df.fillna("")

# =========================
# APPLICATION STATISTICS
# =========================

total_applications = len(
    applications_df
)

shortlisted_count = len(
    applications_df[
        applications_df["status"]
        == "Shortlisted"
    ]
)

rejected_count = len(
    applications_df[
        applications_df["status"]
        == "Rejected"
    ]
)

selected_count = len(
    applications_df[
        applications_df["status"]
        == "Selected"
    ]
)

col1, col2, col3, col4 = st.columns(4)

with col1:

    st.metric(
        "Applications",
        total_applications
    )

with col2:

    st.metric(
        "Shortlisted",
        shortlisted_count
    )

with col3:

    st.metric(
        "Rejected",
        rejected_count
    )

with col4:

    st.metric(
        "Selected",
        selected_count
    )

# =========================
# APPLICATION TABLE
# =========================

st.markdown("---")

if len(
    applications_df
) == 0:

    st.info(
        "No applications received yet."
    )

else:

    st.subheader(
        "Received Applications"
    )

    edited_df = st.data_editor(

        applications_df[
            [
                "name",
                "email",
                "phone",
                "resume_name",
                "job_title",
                "status",
                "match_score"
            ]
        ],

        use_container_width=True,

        hide_index=True,

        column_config={

            "name":
            st.column_config.TextColumn(
                "Applicant Name"
            ),

            "email":
            st.column_config.TextColumn(
                "Email"
            ),

            "phone":
            st.column_config.TextColumn(
                "Phone Number"
            ),

            "resume_name":
            st.column_config.TextColumn(
                "Resume"
            ),

            "job_title":
            st.column_config.TextColumn(
                "Job Applied"
            ),

            "status":
            st.column_config.SelectboxColumn(
                "Status",
                options=[
                    "Applied",
                    "Shortlisted",
                    "Rejected",
                    "Selected"
                ]
            ),

            "match_score":
            st.column_config.TextColumn(
                "Percentage Match"
            )

        },

        disabled=[
            "name",
            "email",
            "phone",
            "resume_name",
            "job_title",
            "match_score"
        ]
    )

    # =========================
    # SAVE STATUS CHANGES
    # =========================

    if st.button(
        "Save Changes"
    ):

        applications_df["status"] = (
            edited_df["status"]
        )

        applications_df.to_csv(
            APPLICATIONS_FILE,
            index=False
        )

        st.success(
            "Application statuses updated successfully."
        )

        st.rerun()

# =========================
# BACK BUTTON
# =========================

st.markdown("---")

if st.button(
    "Back To Recruiter Dashboard"
):

    st.switch_page(
        "pages/RECRUITER DASHBOARD.py"
    )




