import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()


st.set_page_config(
    page_title="Applicant Dashboard"
)

APPLICATIONS_FILE = "data/applications.csv"

os.makedirs(
    "data",
    exist_ok=True
)

# =========================
# LOGIN CHECK
# =========================

if "email" not in st.session_state:

    st.error(
        "Please login first."
    )

    st.stop()

email = st.session_state["email"]

# =========================
# APPLICATION FILE
# =========================

if not os.path.exists(
    APPLICATIONS_FILE
):

    pd.DataFrame(
        columns=[
            "name",
            "email",
            "phone",
            "resume_name",
            "job_title",
            "company_name",
            "status",
            "shortlisted"
        ]
    ).to_csv(
        APPLICATIONS_FILE,
        index=False
    )

# =========================
# LOAD DATA
# =========================

applications_df = pd.read_csv(
    APPLICATIONS_FILE,
    dtype=str
).fillna("")

if "company_name" not in applications_df.columns:
    applications_df["company_name"] = ""

if "shortlisted" not in applications_df.columns:
    applications_df["shortlisted"] = "No"

user_df = applications_df[
    applications_df["email"] == email
].copy()

# =========================
# SESSION STATE
# =========================

if "edit_mode" not in st.session_state:

    st.session_state[
        "edit_mode"
    ] = False

# =========================
# HEADER
# =========================

col1, col2 = st.columns(
    [8, 1]
)

with col1:

    st.title(
        "My Applications"
    )

with col2:

    if st.button(
        "Edit"
    ):

        st.session_state[
            "edit_mode"
        ] = not st.session_state[
            "edit_mode"
        ]

        st.rerun()

# =========================
# NO APPLICATIONS
# =========================

if user_df.empty:

    st.info(
        "You have not applied for any jobs yet."
    )

# =========================
# READ ONLY MODE
# =========================

elif not st.session_state[
    "edit_mode"
]:

    display_df = user_df[
        [
            "company_name",
            "job_title",
            "shortlisted",
            "status"
        ]
    ].copy()

    display_df.columns = [
        "Company Name",
        "Role",
        "Shortlisted",
        "Remarks"
    ]

    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True
    )

# =========================
# EDIT MODE
# =========================

else:

    st.info(
        "Edit Mode Enabled"
    )

    st.markdown("---")

    # TABLE HEADER

    h1, h2, h3, h4, h5 = st.columns(
        [3, 4, 2, 3, 2]
    )

    h1.markdown("**Company Name**")
    h2.markdown("**Role**")
    h3.markdown("**Shortlisted**")
    h4.markdown("**Remarks**")
    h5.markdown("**Action**")

    st.markdown("---")

    # TABLE ROWS

    for idx in user_df.index:

        row = user_df.loc[idx]

        c1, c2, c3, c4, c5 = st.columns(
            [3, 4, 2, 3, 2]
        )

        with c1:

            st.markdown(
                f"""
                <div style="
                    padding-top:10px;
                    white-space:nowrap;
                ">
                    {row['company_name']}
                </div>
                """,
                unsafe_allow_html=True
            )

        with c2:

            st.markdown(
                f"""
                <div style="
                    padding-top:10px;
                    white-space:nowrap;
                ">
                    {row['job_title']}
                </div>
                """,
                unsafe_allow_html=True
            )

        with c3:

            st.selectbox(
                label="",
                options=["No", "Yes"],
                index=(
                    1
                    if row.get(
                        "shortlisted",
                        "No"
                    ) == "Yes"
                    else 0
                ),
                key=f"short_{idx}",
                label_visibility="collapsed"
            )

        with c4:

            st.text_input(
                label="",
                value=row["status"],
                key=f"status_{idx}",
                label_visibility="collapsed"
            )

        with c5:

            if st.button(
                "Delete",
                key=f"delete_{idx}",
                use_container_width=True
            ):

                applications_df = applications_df.drop(
                    idx
                )

                applications_df.to_csv(
                    APPLICATIONS_FILE,
                    index=False
                )

                st.success(
                    "Application deleted successfully."
                )

                st.rerun()

        st.markdown("---")

    # =========================
    # ACTION BUTTONS
    # =========================

    save_col, cancel_col = st.columns(
        [1, 1]
    )

    with save_col:

        if st.button(
            "Save Changes",
            use_container_width=True
        ):

            for idx in user_df.index:

                applications_df.loc[
                    idx,
                    "shortlisted"
                ] = st.session_state[
                    f"short_{idx}"
                ]

                applications_df.loc[
                    idx,
                    "status"
                ] = st.session_state[
                    f"status_{idx}"
                ]

            applications_df.to_csv(
                APPLICATIONS_FILE,
                index=False
            )

            st.session_state[
                "edit_mode"
            ] = False

            st.success(
                "Changes saved successfully."
            )

            st.rerun()

    with cancel_col:

        if st.button(
            "Cancel Editing",
            use_container_width=True
        ):

            st.session_state[
                "edit_mode"
            ] = False

            st.rerun()