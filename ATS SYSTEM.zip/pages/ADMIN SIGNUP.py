import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()



st.set_page_config(
    page_title="Admin Sign Up"
)

st.title("Admin Sign Up")

USERS_FILE = "data/users.csv"

os.makedirs(
    "data",
    exist_ok=True
)

# =========================
# CREATE USERS FILE
# =========================

if not os.path.exists(USERS_FILE):

    pd.DataFrame(columns=[
        "email",
        "password",
        "role",
        "admin_secret"
    ]).to_csv(
        USERS_FILE,
        index=False
    )

# =========================
# INPUT FIELDS
# =========================

st.markdown("---")

email = st.text_input(
    "Admin Email"
)

password = st.text_input(
    "Password",
    type="password"
)

confirm_password = st.text_input(
    "Confirm Password",
    type="password"
)

admin_secret = st.text_input(
    "Admin Secret Key",
    type="password"
)

# =========================
# CREATE ADMIN ACCOUNT
# =========================

if st.button(
    "Create Admin Account"
):

    if not all([
        email,
        password,
        confirm_password,
        admin_secret
    ]):

        st.error(
            "Please fill all fields."
        )

    elif password != confirm_password:

        st.error(
            "Passwords do not match."
        )

    else:

        users_df = pd.read_csv(
            USERS_FILE
        )

        # Add admin_secret column if missing

        if "admin_secret" not in users_df.columns:

            users_df["admin_secret"] = ""

        if email in users_df["email"].values:

            st.error(
                "Email already registered."
            )

        else:

            new_admin = pd.DataFrame([{
                "email": email,
                "password": password,
                "role": "Admin",
                "admin_secret": admin_secret
            }])

            users_df = pd.concat(
                [
                    users_df,
                    new_admin
                ],
                ignore_index=True
            )

            users_df.to_csv(
                USERS_FILE,
                index=False
            )

            st.success(
                "Admin account created successfully."
            )

            st.info(
                "Please login through the Admin Portal."
            )

# =========================
# BACK BUTTON
# =========================

st.markdown("---")

if st.button(
    "Back To Admin Login"
):

    st.switch_page(
        "ADMIN.py"
    )