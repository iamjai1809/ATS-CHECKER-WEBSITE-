import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()




st.set_page_config(page_title="Sign Up")

st.title("Create Account")

USERS_FILE = "data/users.csv"

os.makedirs("data", exist_ok=True)

email = st.text_input("Email")

password = st.text_input(
    "Password",
    type="password"
)

confirm_password = st.text_input(
    "Confirm Password",
    type="password"
)

# ROLE SELECTION
role = st.selectbox(
    "Register As",
    ["Applicant", "Recruiter"]
)

if st.button("Create Account"):

    if not email or not password or not confirm_password:
        st.error("Please fill all fields")

    elif password != confirm_password:
        st.error("Passwords do not match")

    else:

        if os.path.exists(USERS_FILE):

            try:

                users_df = pd.read_csv(USERS_FILE)

            except pd.errors.EmptyDataError:

                users_df = pd.DataFrame(
                    columns=[
                        "email",
                        "password",
                        "role"
                    ]
                )

        else:

            users_df = pd.DataFrame(
                columns=[
                    "email",
                    "password",
                    "role"
                ]
            )

        # Check if already registered
        if email in users_df["email"].values:
            st.error("Email already registered")

        else:

            new_user = pd.DataFrame([{
                "email": email,
                "password": password,
                "role": role
            }])

            users_df = pd.concat(
                [users_df, new_user],
                ignore_index=True
            )

            users_df.to_csv(
                USERS_FILE,
                index=False
            )

            st.success("Account created successfully!")
            st.info("Please login with your new account.")

            st.switch_page("HOME.py")