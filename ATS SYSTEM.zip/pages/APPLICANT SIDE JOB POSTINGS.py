import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()



st.set_page_config(
    page_title="Job Portal"
)

st.title("Available Jobs")

col1, col2 = st.columns([8, 1])

with col2:

    if st.button("Profile"):

        st.switch_page(
            "pages/APPLICANT PROFILE.py"
        )

# =========================
# LOGIN CHECK
# =========================

if "logged_in" not in st.session_state:

    st.error(
        "Please login first."
    )

    st.stop()

# =========================
# FILE PATH
# =========================

JOBS_FILE = "data/jobs.csv"

os.makedirs(
    "data",
    exist_ok=True
)

# =========================
# LOAD JOBS FILE
# =========================

try:

    jobs_df = pd.read_csv(
        JOBS_FILE,
        dtype=str
    ).fillna("")

except Exception:

    st.error(
        "Unable to load jobs."
    )

    st.stop()

# =========================
# CLEAN COLUMN NAMES
# =========================

jobs_df.columns = jobs_df.columns.str.strip()

# =========================
# DISPLAY JOBS
# =========================

if jobs_df.empty:

    st.info(
        "No jobs available currently."
    )

else:

    for index, job in jobs_df.iterrows():

        st.markdown("---")

        st.subheader(
            job.get(
                "job_title",
                "Untitled Job"
            )
        )

        st.write(
            f"Company Name: {job.get('company_name', 'Not Specified')}"
        )

        st.write(
            f"Location: {job.get('location', 'Not Specified')}"
        )

        st.write(
            f"Employment Type: {job.get('employment_type', 'Not Specified')}"
        )

        st.write(
            f"Experience Required: {job.get('experience', 'Not Specified')}"
        )

        st.write(
            f"Salary Offered: {job.get('salary', 'Not Specified')}"
        )

        st.markdown("### Job Summary")

        st.write(
            job.get(
                "job_summary",
                "Not Available"
            )
        )

        st.markdown("### Responsibilities")

        st.write(
            job.get(
                "responsibilities",
                "Not Available"
            )
        )

        st.markdown("### Required Skills")

        st.write(
            job.get(
                "required_skills",
                "Not Available"
            )
        )

        st.markdown("### Qualifications")

        st.write(
            job.get(
                "qualifications",
                "Not Available"
            )
        )

        button_key = (
            f"apply_{job.get('job_id', index)}_{index}"
        )

        if st.button(
            f"Apply for {job.get('job_title', 'Job')}",
            key=button_key
        ):

            st.session_state[
                "selected_job"
            ] = job.get(
                "job_title",
                "Unknown Job"
            )

            st.session_state[
                "selected_company"
            ] = job.get(
                "company_name",
                "Unknown Company"
            )

            # ATS Matching Content

            st.session_state[
                "selected_description"
            ] = f"""
            {job.get('job_summary', '')}

            {job.get('responsibilities', '')}

            {job.get('required_skills', '')}

            {job.get('qualifications', '')}
            """

            st.session_state[
                "selected_job_id"
            ] = job.get(
                "job_id",
                str(index)
            )

            st.switch_page(
                "pages/APPLICANT APPLYING PAGE.py"
            )