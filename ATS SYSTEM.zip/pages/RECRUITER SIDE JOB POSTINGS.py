# FROM HERE THE RECRUITER SIDE JOB POSTINGS PAGE STARTS

import streamlit as st
import pandas as pd
import os
from ui import apply_ui

st.set_page_config(
    page_title="ATS",
    layout="wide"
)

apply_ui()




st.set_page_config(
    page_title="Recruiter Job Postings",
)

st.title("Recruiter Job Postings")

# =========================
# PROFILE BUTTON
# =========================

header_col1, header_col2 = st.columns([8, 1])

with header_col2:

    if st.button("Profile"):
        st.switch_page(
            "pages/RECRUITER PROFILE.py"
        )

JOBS_FILE = "data/jobs.csv"

os.makedirs("data", exist_ok=True)

# =========================
# LOGIN CHECK
# =========================

if "logged_in" not in st.session_state:
    st.error("Please login first.")
    st.stop()

if "email" not in st.session_state:
    st.session_state["email"] = None

if st.session_state["email"] is None:
    st.error("Please login first.")
    st.stop()

current_recruiter = st.session_state["email"]

# =========================
# ENSURE JOB FILE EXISTS
# =========================

if not os.path.exists(JOBS_FILE):

    pd.DataFrame(columns=[
        "company_name",
        "job_title",
        "location",
        "employment_type",
        "experience",
        "description",
        "qualifications",
        "salary",
        "posted_by"
    ]).to_csv(
        JOBS_FILE,
        index=False
    )

# =========================
# SAFE JOBS LOADER
# =========================

def load_jobs():

    try:

        jobs_df = pd.read_csv(
            JOBS_FILE,
            dtype=str
        ).fillna("")

    except (
        pd.errors.EmptyDataError,
        pd.errors.ParserError
    ):

        jobs_df = pd.DataFrame(columns=[
          
    "company_name",
        "job_title",
        "location",
        "employment_type",
        "experience",
        "salary",
        "job_summary",
        "responsibilities",
        "required_skills",
        "qualifications",
        "status",
        "posted_by"
        ])


        jobs_df.to_csv(
            JOBS_FILE,
            index=False
        )

    required_columns = [

    "company_name",
        "job_title",
        "location",
        "employment_type",
        "experience",
        "salary",
        "job_summary",
        "responsibilities",
        "required_skills",
        "qualifications",
        "status",
        "posted_by"

    ]

    for col in required_columns:

        if col not in jobs_df.columns:
            jobs_df[col] = ""

    return jobs_df

# =========================
# POST NEW JOB
# =========================

st.subheader("Post New Job")

company_name = st.text_input(
    "Company Name"
)

job_title = st.text_input(
    "Job Title"
)

location = st.text_input(
    "Location"
)

experience = st.text_input(
    "Experience Required"
)

employment_type = st.selectbox(
    "Employment Type",
    ["Full-time", "Part-time", "Contract", "Internship"]
)

job_summary = st.text_area(
    "Job Summary"
)

responsibilities = st.text_area(
    "Responsibilities"
)

required_skills = st.text_area(
    "Required Skills"
)

qualifications = st.text_area(
    "Qualifications Required"
)

salary = st.text_input(
    "Salary Offered"
)

if st.button("Post Job"):

    if not all([
       
    "company_name",
        "job_title",
        "location",
        "employment_type",
        "experience",
        "salary",
        "job_summary",
        "responsibilities",
        "required_skills",
        "qualifications",
        "status",
        "posted_by"

    ]):

        st.error(
            "Please fill all fields"
        )

    else:

        jobs_df = load_jobs()

        new_job = pd.DataFrame([{
            "company_name": str(company_name),
            "job_title": str(job_title),
            "location": str(location),
            "employment_type": str(employment_type),
            "experience": str(experience),
            "job_summary": str(job_summary),
            "responsibilities": str(responsibilities),
            "required_skills": str(required_skills),
            "qualifications": str(qualifications),
            "salary": str(salary),
            "posted_by": str(current_recruiter)
        }])

        jobs_df = pd.concat(
            [jobs_df, new_job],
            ignore_index=True
        )

        jobs_df.to_csv(
            JOBS_FILE,
            index=False
        )

        st.success(
            "Job Posted Successfully"
        )

        st.rerun()

# =========================
# VIEW POSTED JOBS
# =========================

st.markdown("---")

st.subheader("Posted Jobs")

jobs_df = load_jobs()

jobs_df = jobs_df[
    jobs_df["posted_by"]
    == current_recruiter
]

if "editing_job" not in st.session_state:
    st.session_state["editing_job"] = None

if len(jobs_df) == 0:

    st.info(
        "No jobs posted yet."
    )

else:

    for index, job in jobs_df.iterrows():

        st.markdown("---")

        st.write(
            f"Company Name: {job['company_name']}"
        )

        st.write(
            f"Title: {job['job_title']}"
        )

        st.write(
            f"Location: {job['location']}"
        )

        st.write(
            f"Experience: {job['experience']}"
        )

        st.write(
            f"Summary: {job['job_summary']}"
        )

        st.write(
            f"Responsibilities: {job['responsibilities']}"
        )

        st.write(
            f"Required Skills: {job['required_skills']}"
        )

        st.write(
            f"Qualifications Required: {job['qualifications']}"
        )

        st.write(
            f"Salary Offered: {job['salary']}"
        )

        col1, col2 = st.columns([1, 3])

        with col1:

            if st.button(
                "Edit",
                key=f"edit_{index}"
            ):

                st.session_state[
                    "editing_job"
                ] = index

                st.rerun()

        with col2:

            if st.button(
                f"Delete {job['job_title']}",
                key=f"delete_{index}"
            ):

                jobs_df_full = load_jobs()

                jobs_df_full = jobs_df_full.drop(
                    index
                )

                jobs_df_full.to_csv(
                    JOBS_FILE,
                    index=False
                )

                st.success(
                    "Job Deleted Successfully"
                )

                st.rerun()

        if (
            st.session_state[
                "editing_job"
            ] == index
        ):

            updated_company_name = st.text_input(
                "Company Name",
                value=str(job["company_name"]),
                key=f"company_{index}"
            )

            updated_title = st.text_input(
                "Job Title",
                value=str(job["job_title"]),
                key=f"title_{index}"
            )

            updated_location = st.text_input(
                "Location",
                value=str(job["location"]),
                key=f"location_{index}"
            )

            updated_experience = st.text_input(
                "Experience Required",
                value=str(job["experience"]),
                key=f"experience_{index}"
            )

            updated_job_summary = st.text_area(
                "Job Summary",
                value=str(job["job_summary"]),
                key=f"job_summary_{index}"
            )

            updated_responsibilities = st.text_area(
                "Responsibilities",
                value=str(job["responsibilities"]),
                key=f"responsibilities_{index}"
            )

            updated_required_skills = st.text_area(
                "Required Skills",
                value=str(job["required_skills"]),
                key=f"required_skills_{index}"
            )

            updated_qualifications = st.text_area(
                "Qualifications Required",
                value=str(job["qualifications"]),
                key=f"qualifications_{index}"
            )

            updated_salary = st.text_input(
                "Salary Offered",
                value=str(job["salary"]),
                key=f"salary_{index}"
            )

            if st.button(
                "Save Changes",
                key=f"save_{index}"
            ):

                jobs_df_full = load_jobs()

                jobs_df_full.at[
                    index,
                    "company_name"
                ] = str(updated_company_name)

                jobs_df_full.at[
                    index,
                    "job_title"
                ] = str(updated_title)

                jobs_df_full.at[
                    index,
                    "location"
                ] = str(updated_location)

                jobs_df_full.at[
                    index,
                    "experience"
                ] = str(updated_experience)

                jobs_df_full.at[
                    index,
                    "job_summary"
                ] = str(updated_job_summary)

                jobs_df_full.at[
                    index,
                    "responsibilities"
                ] = str(updated_responsibilities)

                jobs_df_full.at[
                    index,
                    "required_skills"
                ] = str(updated_required_skills)

                jobs_df_full.at[
                    index,
                    "qualifications"
                ] = str(updated_qualifications)

                jobs_df_full.at[
                    index,
                    "salary"
                ] = str(updated_salary)

                jobs_df_full.to_csv(
                    JOBS_FILE,
                    index=False
                )

                st.session_state[
                    "editing_job"
                ] = None

                st.success(
                    "Job Updated Successfully"
                )

                st.rerun()