import streamlit as st
from pathlib import Path


def apply_ui():
    """
    Load custom CSS from assets/styles.css
    """

    css_file = Path(__file__).parent / "assets" / "styles.css"

    if css_file.exists():
        with open(css_file, "r", encoding="utf-8") as f:
            css = f.read()

        st.markdown(
            f"""
            <style>
            {css}
            </style>
            """,
            unsafe_allow_html=True,
        )

    else:
        st.warning(
            f"CSS file not found: {css_file}"
        )